# HTML_Project
Name - Ayush Verma
Roll no - 75
Branch- CSE AI
Section- A
# Project Key points
1. Include proper HTML boilerplate  
2. Use multiple headings and descriptive paragraphs 
to explain your gadget. 
3. text formatting: bold, italic.
4. horizontal rule and line breaks. 
5. one link. 
6. one image with alt text and width/height attributes. 
7. one ordered list and one unordered list 
8. a table with a header row and three data rows
9. neat indentation. 